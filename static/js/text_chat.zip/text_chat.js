var apiKey, sessionId, token, notify_session, text_session;

function sendMessage(msg) {
    text_session.signal(
        {
            data: {
                message: msg,
                sender: user,
                receiver: user2
            }
        },
        function (error) {

        }
    );

    notify_session.signal(
        {
            data: {
                notification: name2 + ' send you a message',
                origin: 'chat',
                target: '/online_message/',
                sender: user,
                receiver: user2
            }
        },
        function (error) {

        }
    );
}

function initOpentok() {
    $('#chatBox').empty();
    $('#chatBtn').off('click');
    // var notify_session;

    $.get('/get_notification_session/?user=' + user2, function (res) {
        res = JSON.parse(res);
        apiKey = res.apiKey;
        sessionId = res.sessionId;
        token = res.token;
        notify_session = OT.initSession(apiKey, sessionId);

        notify_session.on("signal", function(event) {

        });

        notify_session.connect(token, function(error) {

        });
    });

    $.get('/get_tchat_session/?user=' + user2, function(res) {
        res = JSON.parse(res);
        apiKey = res.apiKey;
        sessionId = res.sessionId;
        token = res.token;
        text_session = OT.initSession(apiKey, sessionId);

        text_session.on("signal", function(event) {
            if (event.data.sender == user && event.data.receiver == user2) {
                resMsg = '<li><div class="col-md-6 clearfix"></div><div class="col-md-6 npr" id="sender_send_message"><div class="vd_bg-blue chat-wrap"><div class="col-md-12"><p class="messages-content vd_white">' + event.data.message + '</p></div><div class="col-md-12"></div><div class="col-md-12"><div class="messages-from text-right"><span class="time-stamp vd_white chat-date">&nbsp;</span></div></div><div class="clearfix"></div></div></li>';
            }
            else if (event.data.sender == user2 && event.data.receiver == user) {
                resMsg = '<li><div class="col-md-6 npl"><div class="vd_bg-grey reciever-chat-wrap"><div class="col-md-12"><p class="messages-content vd_white">' + event.data.message + '</p></div><div class="col-md-12"><div class="messages-from text-right"><span class="time-stamp vd_white chat-date">&nbsp;</span></div></div><div class="clearfix"></div></div></div><div class="col-md-6 clearfix"></div></li>';
            }
            $('#chatBox').append(resMsg);
        });

        text_session.connect(token, function(error) {

        });

        $('#chatBtn').on('click', function () {
            msg = $('#chatMsg').val();
            send = true;

            $.ajax({
                url: '/put_tchat_data/',
                type: 'POST',
                data: {
                    'message': msg,
                    'user': user2
                },
                success: function (response) {
                    if (response) {
                        alert(response);
                    }
                    if (response.indexOf('Error') < 0) {
                        sendMessage(msg);
                    }
                }
            });

            $('#chatMsg').val('');
        });
    });

    $.ajax({
        url: '/get_tchat_archive/?user=' + user2,
        type: 'GET',
        dataType: 'json',
        success: function (response) {
            var count = Object.keys(response).length;
            for(var i=0;i<count;i++) {
                if (response[i].fields.sender == user && response[i].fields.receiver == user2) {
                    resMsg = '<li><div class="col-md-6 clearfix"></div><div class="col-md-6 npr" id="sender_send_message"><div class="vd_bg-blue chat-wrap"><div class="col-md-12"><p class="messages-content vd_white">' + response[i].fields.message + '</p></div><div class="col-md-12"></div><div class="col-md-12"><div class="messages-from text-right"><span class="time-stamp vd_white chat-date">&nbsp;</span></div></div><div class="clearfix"></div></div></li>';
                }
                else if (response[i].fields.sender == user2 && response[i].fields.receiver == user) {
                    resMsg = '<li><div class="col-md-6 npl"><div class="vd_bg-grey reciever-chat-wrap"><div class="col-md-12"><p class="messages-content vd_white">' + response[i].fields.message + '</p></div><div class="col-md-12"><div class="messages-from text-right"><span class="time-stamp vd_white chat-date">&nbsp;</span></div></div><div class="clearfix"></div></div></div><div class="col-md-6 clearfix"></div></li>'
                }
                $('#chatBox').append(resMsg);
            }
        }
    });
}

$(document).ready(function() {
    if (!(navigator.userAgent.indexOf('Safari') != -1 && navigator.userAgent.indexOf('Chrome') == -1)) {
        initOpentok();
    }
});
